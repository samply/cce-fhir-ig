# TNMT CS - CCE FHIR Implementation Guide v0.6.1

## CodeSystem: TNMT CS 

 
TNM T-Category 

This Code system is referenced in the definition of the following value sets:

* [TNMT VS](ValueSet-TNMTVS.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "TNMTCS",
  "url" : "https://www.cancercoreeurope.eu/fhir/core/CodeSystem/TNMTCS",
  "version" : "0.6.1",
  "name" : "TNMTCS",
  "title" : "TNMT CS",
  "status" : "draft",
  "date" : "2026-09-18T11:46:38+00:00",
  "publisher" : "CCE",
  "contact" : [{
    "name" : "CCE",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.cancercoreeurope.eu"
    }]
  }],
  "description" : "TNM T-Category",
  "caseSensitive" : true,
  "compositional" : false,
  "content" : "complete",
  "count" : 40,
  "concept" : [{
    "code" : "0",
    "display" : "0"
  },
  {
    "code" : "1",
    "display" : "1"
  },
  {
    "code" : "1a",
    "display" : "1a"
  },
  {
    "code" : "1a1",
    "display" : "1a1"
  },
  {
    "code" : "1a2",
    "display" : "1a2"
  },
  {
    "code" : "1b",
    "display" : "1b"
  },
  {
    "code" : "1b1",
    "display" : "1b1"
  },
  {
    "code" : "1b2",
    "display" : "1b2"
  },
  {
    "code" : "1c",
    "display" : "1c"
  },
  {
    "code" : "1c1",
    "display" : "1c1"
  },
  {
    "code" : "1c2",
    "display" : "1c2"
  },
  {
    "code" : "1c3",
    "display" : "1c3"
  },
  {
    "code" : "1d",
    "display" : "1d"
  },
  {
    "code" : "1mi",
    "display" : "1mi"
  },
  {
    "code" : "2",
    "display" : "2"
  },
  {
    "code" : "2a",
    "display" : "2a"
  },
  {
    "code" : "2a1",
    "display" : "2a1"
  },
  {
    "code" : "2a2",
    "display" : "2a2"
  },
  {
    "code" : "2b",
    "display" : "2b"
  },
  {
    "code" : "2c",
    "display" : "2c"
  },
  {
    "code" : "2d",
    "display" : "2d"
  },
  {
    "code" : "3",
    "display" : "3"
  },
  {
    "code" : "3a",
    "display" : "3a"
  },
  {
    "code" : "3b",
    "display" : "3b"
  },
  {
    "code" : "3c",
    "display" : "3c"
  },
  {
    "code" : "3d",
    "display" : "3d"
  },
  {
    "code" : "4",
    "display" : "4"
  },
  {
    "code" : "4a",
    "display" : "4a"
  },
  {
    "code" : "4b",
    "display" : "4b"
  },
  {
    "code" : "4c",
    "display" : "4c"
  },
  {
    "code" : "4d",
    "display" : "4d"
  },
  {
    "code" : "4e",
    "display" : "4e"
  },
  {
    "code" : "a",
    "display" : "a"
  },
  {
    "code" : "is",
    "display" : "is"
  },
  {
    "code" : "is(DCIS)",
    "display" : "is(DCIS)"
  },
  {
    "code" : "is(LCIS)",
    "display" : "is(LCIS)"
  },
  {
    "code" : "is(Paget)",
    "display" : "is(Paget)"
  },
  {
    "code" : "is(pd)",
    "display" : "is(pd)"
  },
  {
    "code" : "is(pu)",
    "display" : "is(pu)"
  },
  {
    "code" : "X",
    "display" : "X"
  }]
}

```
