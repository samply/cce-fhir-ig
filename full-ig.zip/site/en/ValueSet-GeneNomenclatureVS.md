# Gene Nomenclature VS - CCE FHIR Implementation Guide v0.6.4

## ValueSet: Gene Nomenclature VS 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (Unknown Code System)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "GeneNomenclatureVS",
  "url" : "https://www.cancercoreeurope.eu/fhir/core/ValueSet/GeneNomenclatureVS",
  "version" : "0.6.4",
  "name" : "GeneNomenclatureVS",
  "title" : "Gene Nomenclature VS",
  "status" : "draft",
  "date" : "2026-10-22T11:42:36+00:00",
  "publisher" : "CCE",
  "contact" : [{
    "name" : "CCE",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.cancercoreeurope.eu"
    }]
  }],
  "description" : "HUGO Gene Nomenclature",
  "compose" : {
    "include" : [{
      "system" : "http://www.genenames.org"
    }]
  }
}

```
